import clickOutside from './clickOutside';

export default {
  clickOutside
};

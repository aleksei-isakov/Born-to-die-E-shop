const PRICE = 'price';
const START_NUMBER_OF_PAGE = 1;

export { PRICE, START_NUMBER_OF_PAGE };

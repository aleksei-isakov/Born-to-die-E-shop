const getters = {
  productInfo: (state) => state.productInfo,
  isError: (state) => state.isError
};

export default getters;

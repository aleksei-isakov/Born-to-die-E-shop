const state = {
  productInfo: {
    name: '',
    date: '',
    price: 0,
    images: [],
    description: '',
    feedbacks: [],
    averageRating: 0
  },
  isLoading: false,
  isError: false
};

export default state;

const state = {
  isError: false,
  errorMessage: ''
};

export default state;

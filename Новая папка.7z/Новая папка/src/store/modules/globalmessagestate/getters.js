const getters = {
  isError: (state) => state.isError,
  errorMessage: (state) => state.errorMessage
};

export default getters;

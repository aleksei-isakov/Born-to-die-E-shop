const state = {
  isError: false,
  isLoading: false,
  currentUserInfo: null,
  errorMessageRegister: null,
  errorMessageLogin: null
};

export default state;

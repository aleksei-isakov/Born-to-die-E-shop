const getters = {
  currentUserInfo: (state) => state.currentUserInfo,
  errorMessageLogin: (state) => state.errorMessageLogin,
  errorMessageRegister: (state) => state.errorMessageRegister
};

export default getters;

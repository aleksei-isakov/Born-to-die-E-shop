const state = {
  productsList: [],
  errorCode: null,
  isLoading: false
};

export default state;

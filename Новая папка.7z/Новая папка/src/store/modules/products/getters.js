const getters = {
  productsList: (state) => state.productsList,
  errorCode: (state) => state.errorCode
};

export default getters;

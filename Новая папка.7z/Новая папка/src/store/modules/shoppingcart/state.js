const state = {
  productsInCart: [],
  isError: false,
  isLoading: false
};

export default state;

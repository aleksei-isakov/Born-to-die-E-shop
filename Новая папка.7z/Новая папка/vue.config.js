module.exports = {
  lintOnSave: true,

  transpileDependencies: ['vuetify']
};
